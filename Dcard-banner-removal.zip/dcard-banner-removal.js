let banner = ""
setInterval(() => {
    banner =  (document.querySelector(".fMNFMJ")) ? document.querySelector(".fMNFMJ") : ""
    if (banner) {
        banner.style.display = "none";
    }
}, 3000)