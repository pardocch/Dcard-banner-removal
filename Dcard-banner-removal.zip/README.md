# Dcard-banner-removal

** This extension will remove the pop-up banner on the Dcard while it is not logged in. **